
mydata <- read.csv(file="D:/R Analytics/Analytixlabs/Logistic/Proactive Attrition Management.csv",header =T)

# str(mydata)
# View(mydata)

mydata_2 <- subset(mydata,select=-c(CUSTOMER,CSA))

mystats=function(x){
    n<-length(x)
    nmiss<-sum(is.na(x))
    a <- x[!is.na(x)]
    mean<-mean(a)
    median <- median(a)
    std<-sd(a)
    var<-var(a)
    min<-min(a)
    p01 <- quantile(a,0.01)
    p05 <- quantile(a,0.05)
    p90<-quantile(a, 0.90)
    p95<-quantile(a, 0.95)
    p97 <- quantile(a,0.97)
    p98 <- quantile(a,0.98)
    p99<-quantile(a,0.99)
    max<-max(a)
    UC1=mean+3*std
    LC1=mean-3*std
    return(c(n=n,nmiss=nmiss,mean=mean,std=std,var=var,min=min,p01=p01,median=median,p05=p05,p90=p90,p95=p95,p97=p97,p98=p98,p99=p99,max=max))
  }


require(dplyr)

diag_stats <- t(data.frame(apply(mydata_2,2,mystats)))


write.csv(diag_stats, file="D:/R Analytics/Analytixlabs/Logistic/diag_stats.csv")


########### Upper outliers Capping with 95 Percentile####################

for(i in colnames(mydata_2)){
  mydata_2[[i]][mydata_2[[i]]>quantile(mydata_2[[i]],0.95,na.rm=T)] <- quantile(mydata_2[[i]],0.95,na.rm = T)
}

##### Lower outlier capping less than 5 Percentile

for(i in colnames(mydata_2)){
  mydata_2[[i]][mydata_2[[i]]<quantile(mydata_2[[i]],0.05,na.rm=T)] <- quantile(mydata_2[[i]],0.05,na.rm = T)
}


###### Running the function again to check the descriptive stats after capping ### 

diag_stats_1 <- t(data.frame(apply(mydata_2,2,mystats)))


write.csv(diag_stats_1, file="D:/R Analytics/Analytixlabs/Logistic/diag_stats_1.csv")

####### Imputing missing values in below columns ##############

vars <- c("REVENUE","MOU","RECCHRGE","DIRECTAS","OVERAGE","ROAM",
          "CHANGEM","CHANGER","PHONES","MODELS","EQPDAYS","AGE1","AGE2")




#### As there are not too many observations missing, Imputing values for there own column means ##############################


for(i in vars){
  mydata_2[is.na(mydata_2[,i]), i] <- round(median(mydata_2[,i], na.rm = TRUE))
}

categorical_var <- c("CREDITA","CHILDREN","CREDITAA","CREDITB","CREDITC","CREDITDE","CREDITGY","CREDITZ","PRIZMRUR","PRIZMUB",
                     "PRIZMTWN","REFURB","WEBCAP","TRUCK","RV","OCCPROF","OCCCLER","OCCCRFT",
                     "OCCSTUD","OCCHMKR","OCCRET","OCCSELF","OWNRENT","MARRYUN",
                     "MARRYYES","MARRYNO","MAILORD","MAILRES","MAILFLAG","TRAVEL","PCOWN","CREDITCD","NEWCELLY","NEWCELLN","INCMISS","MCYCLE","SETPRCM","RETCALL")




p_value <- c()
cols <- c()

for (i in categorical_var){
  
  mytable <- xtabs(~CHURN+mydata_2[[i]],data=mydata_2)
  test <- chisq.test(mytable)
  p_val <- test$p.value
  cols <- c(cols,i)
  p_value <- c(p_value,p_val)
}


chi_square_results <- data.frame(p_value=p_value,cols=cols)

write.csv(chi_square_results, file="D:/R Analytics/Analytixlabs/Logistic/chi_square_results.csv")


#### Will not take variables related to retention team (retcalls, retcall & retaccpt) as these are recoreded after customer has already think to leave the company ####

### Using all numeric & significant cat variables (after chi square))


fit<-glm(CHURN~	REVENUE+	MOU+	RECCHRGE+	DIRECTAS+	OVERAGE+	ROAM+	CHANGEM+	CHANGER+	DROPVCE+	BLCKVCE+	UNANSVCE+	CUSTCARE+	THREEWAY+	MOUREC+	OUTCALLS+	INCALLS+	PEAKVCE+	
           OPEAKVCE+	DROPBLK+	CALLFWDV+	CALLWAIT+	MONTHS+	UNIQSUBS+	ACTVSUBS+	PHONES+	MODELS+	EQPDAYS+	AGE1+	AGE2+	CREDITA+	CREDITAA+	CREDITB+	CREDITC+	CREDITDE+	CREDITGY+	
           CREDITZ+	PRIZMRUR+	PRIZMUB+	PRIZMTWN+	REFURB+	WEBCAP+	OCCCLER+	OCCCRFT+	OCCSTUD+	OCCHMKR+	OCCRET+	OCCSELF+	OWNRENT+	MARRYUN+	MARRYNO+	MAILORD+	MAILRES+	MAILFLAG+	CREDITCD+	
           NEWCELLY+	REFER+	INCMISS+	INCOME+	MCYCLE+	CREDITAD+	SETPRCM+	SETPRC,data = mydata_2,family = binomial(link="logit"))

summary(fit)

library(MASS)

step3 <- stepAIC(fit,direction="both")

## Important Variables after first Iteration ###

#CHURN ~ REVENUE + MOU + RECCHRGE + OVERAGE + ROAM + CHANGEM + 
# CHANGER + DROPVCE + BLCKVCE + CUSTCARE + THREEWAY + INCALLS + 
#   PEAKVCE + OPEAKVCE + CALLWAIT + MONTHS + UNIQSUBS + ACTVSUBS + 
#   PHONES + EQPDAYS + AGE1 + CREDITAA + CREDITB + CREDITC + 
#   CREDITDE + PRIZMUB + REFURB + WEBCAP + MARRYNO + MAILRES + 
#   CREDITCD + NEWCELLY + INCMISS + INCOME + SETPRC

## Checking Normality ####

# hist(log(mydata_2$REVENUE+1))
# hist(sqrt(mydata_2$MOU+1))
# hist(log(mydata_2$MONTHS+1))
# hist(log(mydata_2$DROPVCE+1))

## Transforming Variables to reduce skewness in the data #####

mydata_2$ln_REVENUE <- log(mydata_2$REVENUE+1)
mydata_2$ln_MOU <- sqrt(mydata_2$MOU+1)
mydata_2$ln_MONTHS <- log(mydata_2$MONTHS+1)
mydata_2$ln_DROPVCE <- log(mydata_2$DROPVCE+1)
mydata_2$ln_EQPDAYS <- sqrt(mydata_2$EQPDAYS+1)



### Spliting data into training and validation dataset ###
## And Run regression on combination of variables which gives lower AIC after stepwise regression ### 

set.seed(12345)  

training <- mydata_2[mydata_2$CALIBRAT==1,]
testing <- mydata_2[mydata_2$CALIBRAT==0,]


fit2 <- glm(CHURN ~ ln_REVENUE + ln_MOU + RECCHRGE + OVERAGE + ROAM + CHANGEM + 
  CHANGER + ln_DROPVCE + BLCKVCE + CUSTCARE + THREEWAY + INCALLS + 
  PEAKVCE + OPEAKVCE + CALLWAIT + ln_MONTHS + UNIQSUBS + ACTVSUBS + 
  PHONES + ln_EQPDAYS + AGE1 + CREDITAA + CREDITB + CREDITC + 
  CREDITDE + PRIZMUB + REFURB + WEBCAP + MARRYNO + MAILRES + 
  CREDITCD + NEWCELLY + INCMISS + INCOME + SETPRC, data=training,family = binomial(link="logit"))


step4 <- stepAIC(fit2,direction="both")




fit3 <- glm(CHURN ~ ln_REVENUE + ln_MOU + RECCHRGE + OVERAGE + ROAM + CHANGEM + 
              CHANGER + ln_DROPVCE + BLCKVCE + THREEWAY + INCALLS + PEAKVCE + 
              OPEAKVCE + CALLWAIT + ln_MONTHS + UNIQSUBS + ACTVSUBS + PHONES + 
              ln_EQPDAYS + AGE1 + CREDITAA + CREDITB+ CREDITDE + 
              PRIZMUB + REFURB + WEBCAP + MARRYNO + MAILRES + NEWCELLY + 
              INCMISS + INCOME + SETPRC, data=training,family = binomial(link="logit"))

summary(fit3)

library(QuantPsyc)
lm.beta(fit3)

################# Training ####################################

train1<- cbind(training, prob=predict(fit3, type="response"))
require(ROCR)
pred_train_fit3 <- prediction(train1$prob, train1$CHURN)
perf_fit3 <- performance(pred_train_fit3, "tpr", "fpr")
plot(perf_fit3)
abline(0, 1)
performance(pred_train_fit3, "auc")@y.values


###### Deciling ######################################


decLocations <- quantile(train1$prob, probs = seq(0.1,0.9,by=0.1))
train1$decile <- findInterval(train1$prob,c(-Inf,decLocations, Inf))
View(train1)

#Decile Analysis Reports
require(sqldf)
fit_train_DA <- sqldf("select decile, min(prob) as Min_prob
                       , max(prob) as max_prob
                       , sum(CHURN) as churn_Count
                       , (count(decile)-sum(CHURN)) as Non_churn_Count 
                      from train1
                      group by decile
                      order by decile desc")
View(fit_train_DA)

write.csv(fit_train_DA,"D:/R Analytics/Analytixlabs/Logistic/fit_train_DA.csv",row.names = F)


#################### Validation/Testing ###########################################

test1 <- cbind(testing, prob=predict(fit3,newdata = testing,type = "response"))

decLocations_test <- quantile(test1$prob,probs = seq(0.1,0.9,by=0.1))

test1$decile <- findInterval(test1$prob,c(-Inf,decLocations_test,Inf))

fit_test1_DA <- sqldf("select decile, min(prob) as Min_prob,
                      max(prob) as Max_prob,
                      sum(CHURN) as churn_count,
                      count(decile)-sum(CHURN) as Non_Churn_Count 
                      from test1 group by decile
                      order by decile desc")
View(fit_test1_DA)


write.csv(fit_test1_DA,"D:/R Analytics/Analytixlabs/Logistic/fit_test1_DA.csv",row.names = F)

### Based on the decile report, this is the best cut-off ######################

table(train1$prob>0.50, train1$CHURN)

table(test1$prob>0.50,test1$CHURN)

log_predict <- ifelse(test1$prob> 0.50,1,0)
pr <- prediction(log_predict,test1$CHURN)

library(Metrics)
perf <- performance(pr,measure = "tpr",x.measure = "fpr")
plot(perf) 
auc(test1$CHURN,log_predict)

## Model Performance is not very good, Boosting and RF might work  better in this case #####



