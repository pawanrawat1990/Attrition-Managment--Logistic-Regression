
library(readxl)
library(dplyr)
Mydata <- read_excel("D:/R Analytics/Analytixlabs/Linear/Linear Regression Case.xlsx", sheet = 1)
View(Mydata)
# str(Mydata)

# colnames(Mydata)



####Creating Target Variable by combining spent of primary and secndary cards #####################

Mydata$total_spend <- Mydata$cardspent+Mydata$card2spent


mystats <- function(x){
  nmiss <- sum(is.na(x))
  a <- x[!is.na(x)]
  m <- mean(a)
  n <- length(a)
  s <- sd(a)
  min <- min(a)
  p90 <- quantile(a,0.90)
  p95 <- quantile(a,0.95)
  p99 <- quantile(a,0.99)
  max <- max(a)
  UC <- m+3*s
  LC <- m-3*s
  outlier_flag <- max>UC|min<LC
  return(c(n=n ,nmiss = nmiss,mean=m,stdev=s,min = min,UC =UC, LC=LC,p90=p90,
            p95=p95,p99=p99,outlier_flag= outlier_flag, max = max))
}



vars <- c("region",	"townsize",	"gender",	"age",	"agecat",	"ed",	"edcat",	"jobcat",	"union",	"employ",	
          "empcat",	"retire",	"income",	"inccat",	"debtinc","creddebt","othdebt",	"default",	"jobsat",	"marital",	"spoused",	
          "spousedcat",	"reside",	"pets",	"pets_cats",	"pets_dogs",	"pets_birds",	"pets_reptiles",	"pets_small",	"pets_saltfish",	"pets_freshfish",	"homeown",	"hometype",	
          "address",	"addresscat",	"cars",	"carown",	"cartype",	"carvalue",	"carcatvalue",	"carbought",	"carbuy",	"commute",	"commutecat",	"commutetime",	"commutecar",	"commutemotorcycle",	
          "commutecarpool",	"commutebus",	"commuterail",	"commutepublic",	"commutebike",	"commutewalk",	"commutenonmotor",	"telecommute",	"reason",	"polview",	"polparty",	"polcontrib",	"vote",	"card",	"cardtype",	
          "cardbenefit",	"cardfee",	"cardtenure",	"cardtenurecat",	"card2",	"card2type",	"card2benefit",	"card2fee",	"card2tenure",	"card2tenurecat",	"active",	"bfast",	"tenure",	"churn",	"longmon",	"longten",	"tollfree",	"tollmon",	"tollten",	"equip",	
          "equipmon",	"equipten",	"callcard",	"cardmon",	"cardten",	"wireless",	"wiremon",	"wireten",	"multline",	"voice",	"pager",	"internet",	"callid",	"callwait",	"forward",	"confer",	"ebill",	"owntv",	"hourstv",	"ownvcr",	"owndvd",	"owncd",	"ownpda",	"ownpc",	"ownipod",	"owngame",	
          "ownfax",	"news",	"response_01",	"response_02",	"response_03","total_spend")


Mydata <- dplyr::select(Mydata,vars)

diag_stats <- t(data.frame(apply(Mydata[vars],2,mystats)))
View(diag_stats)

write.csv(diag_stats, file = "D:/R Analytics/Analytixlabs/Linear/diag_stats_1.csv")

########### outliers Capping with 99 Percentile####################

for(i in vars){
  Mydata[[i]][Mydata[[i]]>quantile(Mydata[[i]],0.99,na.rm=T)] <- quantile(Mydata[[i]],0.99,na.rm = T)
}

##### Outlier capping less than 1 Percentile


for(i in vars){
  Mydata[[i]][Mydata[[i]]<quantile(Mydata[[i]],0.01,na.rm=T)] <- quantile(Mydata[[i]],0.01,na.rm = T)
}



################ Missing Value Imputation-mean ########################################
Mydata$townsize[is.na(Mydata$townsize)] <- 3
Mydata$longten[is.na(Mydata$longten)] <- mean(Mydata$longten,na.rm=TRUE)
Mydata$cardten[is.na(Mydata$cardten)] <- mean(Mydata$cardten,na.rm=TRUE)
Mydata$commutetime[is.na(Mydata$commutetime)] <- mean(Mydata$commutetime,na.rm=TRUE)


### Annova test to check the significant categorical variables ######

ANOVA_segment <- aov(total_spend ~ region+ 	townsize+ 	gender+ 	agecat+ 	edcat+ 	jobcat+ 	union+ 	empcat+ 	retire+ 	inccat+ 	default+ 	jobsat+ 	marital+ 	spousedcat+ 	homeown+ 	hometype+ 	address+ 	addresscat+ 	
                       cars+ 	carown+ 	cartype+ 	carcatvalue+ 	carbought+ 	carbuy+ 	commute+ 	commutecat+ 	commutecar+ 	commutemotorcycle+ 	commutecarpool+ 	commutebus+ 	commuterail+ 	commutepublic+ 	commutebike+ 	commutewalk+ 	
                       commutenonmotor+ 	telecommute+ 	reason+ 	polview+ 	polparty+ 	polcontrib+ 	vote+ 	card+ 	cardtype+ 	cardbenefit+ 	cardfee+ 	cardtenure+ 	cardtenurecat+ 	card2+ 	card2type+ 	card2benefit+ 	card2fee+ 	card2tenure+ 	
                       card2tenurecat+ 	active+ 	bfast+ 	churn+ 	tollfree+ 	equip+ 	callcard+ 	wireless+ 	multline+ 	voice+ 	pager+ 	internet+ 	callid+ 	callwait+ 	forward+ 	confer+ 	ebill+ 	owntv+ 	ownvcr+ 	owndvd+ 	owncd+ 	ownpda+ 	ownpc+ 	
                       ownipod+ 	owngame+ 	ownfax+ 	news+ 	response_01+ 	response_02+ 	response_03, data = Mydata)
summary(ANOVA_segment)

###### Variable Transformation for better predictions ##########################################


hist(log(Mydata$total_spend+1))
Mydata$ln_total_spend <- log(Mydata$total_spend+1)

#### First Linear Model with significant categorical and all continuous variable ###

fit <- lm(ln_total_spend~region+	townsize+	gender+	agecat+	edcat+	empcat+	
            retire+	inccat+	card+	card2+	card2fee+	voice+	
            internet+	response_03+age+	ed+	employ+ debtinc+creddebt+othdebt+	
            +	spoused+	reside+	pets+	pets_cats+	pets_dogs+	pets_birds+	
            pets_reptiles+	pets_small+	pets_saltfish+	pets_freshfish+	carvalue+	
            commutetime+	tenure+	longmon+	longten+	tollmon+	
            tollten+	equipmon+	equipten+	cardmon+	cardten+income+	
            wiremon+	wireten+	hourstv,data= Mydata)

summary(fit)


library(car)
library(MASS)

step3 <- stepAIC(fit,direction="both")

## variables selections after step wise regression ####

ln_total_spend ~ region + gender + agecat + retire + inccat + 
  card + card2 + voice + internet + response_03 + age + pets_reptiles + 
  cardmon + cardten + income

## Converting selected categorical variables as factors ### 

vars2 <- c("region","gender","agecat","inccat","card","card2","response_03","voice","internet")

for(i in vars2){
  Mydata[[i]] <- as.factor(Mydata[[i]])
}

#Splitting data into Training and Testing Dataset

set.seed(123)
train_ind <- sample(1:nrow(Mydata), size = floor(0.70 * nrow(Mydata)))

dev<-Mydata[train_ind,]
val<-Mydata[-train_ind,]


fit2 <- lm(ln_total_spend ~ region + gender + agecat + retire + inccat + 
             card + card2 + voice + internet + response_03 + age + pets_reptiles + 
             cardmon + cardten + income
           ,data= dev)

summary(fit2)

dev$Cd<- cooks.distance(fit2)

dev1<-subset(dev, Cd< (4/3500))

####### Final Model #####

fit3 <- lm(ln_total_spend ~ region + gender + agecat + retire + inccat + 
             card + card2 + voice + internet + response_03 + age + pets_reptiles + 
             cardmon + cardten + income
           ,data= dev1)

summary(fit3)

####################### Prediction on development data ##################################

t1 <- cbind(dev1, pred_spend = exp(predict(fit3,dev1)))

t1$RMSE <- sqrt((t1$pred_spend- t1$total_spend)^2)

#### Creating deciles on dev data set #####

decLocations <- quantile(t1$RMSE , probs = seq(0.1,0.9,by=0.1))
t1$decile <- findInterval(t1$RMSE,c(-Inf,decLocations, Inf))

#Decile Analysis Reports
require(sqldf)
fit_t1_DA <- sqldf("select decile ,sum(pred_spend) as decile_pred_spend, count(decile) as num_customer
                       ,sum(total_spend) as decile_total_spend,min(RMSE) as Min_RMSE_error
                       , max(RMSE) as max_RMSE_error
                       , sum(RMSE) as total_decile_RMSE_error
                      from t1
                      group by decile
                      order by decile desc")

#### Prediction on devlopment data ############################

t2 <- cbind(val, pred_spend = exp(predict(fit3,val)))

t2$RMSE <- sqrt((t2$pred_spend- t2$total_spend)^2)

#### Creating deciles on dev data set #####

decLocations <- quantile(t2$RMSE , probs = seq(0.1,0.9,by=0.1))
t2$decile <- findInterval(t2$RMSE,c(-Inf,decLocations, Inf))

#Decile Analysis Reports
fit_t2_DA <- sqldf("select decile ,sum(pred_spend) as decile_pred_spend, count(decile) as num_customer
                       ,sum(total_spend) as decile_total_spend,min(RMSE) as Min_RMSE_error
                       , max(RMSE) as max_RMSE_error
                       , sum(RMSE) as total_decile_RMSE_error
                      from t2
                      group by decile
                      order by decile desc")

write.csv(fit_t1_DA, file = "D:/R Analytics/Analytixlabs/Linear/fit_t1_DA.csv")
write.csv(fit_t2_DA, file = "D:/R Analytics/Analytixlabs/Linear/fit_t2_DA.csv")


##### Plot Actual vs Predicted Spend #########

plot(t1$pred_spend,t1$total_spend,
     xlab="predicted",ylab="actual")
abline(a=0,b=1)


#### Standardized Beta ##############################################################

library(QuantPsyc)
lm.beta(fit3)

####################### END ##########################################