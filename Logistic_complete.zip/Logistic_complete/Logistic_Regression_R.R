
mydata <- read.csv(file="D:/R Analytics/Analytixlabs/Logistic/Proactive Attrition Management.csv",header =T)

str(mydata)

View(mydata)



# training <- mydata[mydata$CALIBRAT==1,]
# testing <- mydata[mydata$CALIBRAT==0,]
# 
# training$CSA <- NULL
# training$CALIBRAT <- NULL
# training$CUSTOMER <- NULL
# training$CHURN <- as.factor(mydata$CHURN)


# library(caret)
# 
# custom <- trainControl(method="cv",
#                        number=10)
# 
# grid <- expand.grid(maxdepth=10)
# 
# fit2 <- train(CHURN~.,metric="Accuracy",method="rf",trControl=custom,maximise=F,na.action=na.omit,data=training)
# fit2
# varImp(fit2)




mystats=function(x){
    n<-length(x)
    nmiss<-sum(is.na(x))
    a <- x[!is.na(x)]
    mean<-mean(a)
    std<-sd(a)
    var<-var(a)
    min<-min(a)
    p01 <- quantile(a,0.01)
    p90<-quantile(a, 0.90)
    p95<-quantile(a, 0.95)
    p97 <- quantile(a,0.97)
    p98 <- quantile(a,0.98)
    p99<-quantile(a,0.99)
    max<-max(a)
    UC1=mean+3*std
    LC1=mean-3*std
    return(c(n=n,nmiss=nmiss,mean=mean,std=std,var=var,min=min,p01=p01,p90=p90,p95=p95,p97=p97,p98=p98,p99=p99,max=max))
  }

############ selecting variables based on random forest importance and business understanding ####

vars <- c("REVENUE",	"MOU",	"RECCHRGE",	"DIRECTAS",	"OVERAGE",	"ROAM",	"CHANGEM",	"CHANGER",	"DROPVCE",	"BLCKVCE",	"UNANSVCE",	"CUSTCARE",	"THREEWAY",	"MOUREC",	"OUTCALLS",	"INCALLS",	"PEAKVCE",	"OPEAKVCE",	
          "DROPBLK",	"MONTHS",	"UNIQSUBS",	"ACTVSUBS",	"PHONES",	"MODELS",	"EQPDAYS",	"AGE1",	"CHILDREN",	
          "CREDITAA",	"CREDITB",	"CREDITC",	"CREDITDE",	"CREDITGY",	"CREDITZ",	"PRIZMRUR",	"PRIZMUB",	"REFURB",	"WEBCAP",	"MARRYUN","MARRYYES","MARRYNO",
          "CREDITCD",	"NEWCELLY",	"INCMISS",	"INCOME",	"SETPRCM",	"SETPRC")

require(dplyr)

diag_stats <- t(data.frame(apply(mydata[vars],2,mystats)))



write.csv(diag_stats, file="D:/R Analytics/Analytixlabs/Logistic/diag_stats.csv")


########### Upper outliers Capping with 99 Percentile####################

for(i in vars){
  mydata[[i]][mydata[[i]]>quantile(mydata[[i]],0.99,na.rm=T)] <- quantile(mydata[[i]],0.99,na.rm = T)
}

##### Lower outlier capping less than 1 Percentile


for(i in vars){
  mydata[[i]][mydata[[i]]<quantile(mydata[[i]],0.01,na.rm=T)] <- quantile(mydata[[i]],0.01,na.rm = T)
}


####### Imputing missing value in age by median 

missing_index <- which(is.na(mydata$AGE1))
for(i in missing_index){
  mydata$AGE1[i] <- median(mydata$AGE1,na.rm=T)  
}

#### As there are not too many observations missing, Imputing values for there own column means ##############################


for(i in vars){
  mydata[is.na(mydata[,i]), i] <- median(mydata[,i], na.rm = TRUE)
}


sum(mydata$INCOME==0)
sum(mydata$SETPRC==0)


##### Large number of missing values, will exclude these two variable ####

mydata$REVENUE_RECC_RATIO <- mydata$RECCHRGE/mydata$REVENUE
mydata$CHANGEM_IMPACT <- ifelse(mydata$CHANGEM<=0,1,0)
mydata$CHANGER_IMPACT <- ifelse(mydata$CHANGER<=0,1,0)
mydata$UNIQ_ACTIV_RATIO <- mydata$ACTVSUBS/mydata$UNIQSUBS


vars2 <- c("REVENUE",	"MOU",	"RECCHRGE",	"DIRECTAS",	"OVERAGE",	"ROAM",	"CHANGEM",	"CHANGER",	"DROPVCE",	"BLCKVCE",	"UNANSVCE",	"CUSTCARE",	"THREEWAY",	"MOUREC",	"OUTCALLS",	"INCALLS",	"PEAKVCE",	"OPEAKVCE",	
           "DROPBLK",	"MONTHS",	"UNIQSUBS",	"ACTVSUBS",	"PHONES",	"MODELS",	"EQPDAYS",	"AGE1",	"CHILDREN",	
           "CREDITAA",	"CREDITB",	"CREDITC",	"CREDITDE",	"CREDITGY",	"CREDITZ",	"PRIZMRUR",	"PRIZMUB",	"REFURB",	"WEBCAP",	
           "MARRYUN","MARRYYES","MARRYNO",	"CREDITCD",	"NEWCELLY",	"INCMISS",	"INCOME",	"SETPRCM",	"SETPRC","REVENUE_RECC_RATIO","CHANGEM_IMPACT","CHANGER_IMPACT","UNIQ_ACTIV_RATIO")

#### Correlation among the variables, will exclude high correlated variables ##

mydata_1 <- dplyr::select(mydata,vars2)

numeric_var <- sapply(mydata_1, is.numeric)

corr_1 <- cor(mydata_1[numeric_var])


write.csv(corr_1, file="D:/R Analytics/Analytixlabs/Logistic/correlation.csv")



training <- mydata[mydata$CALIBRAT==1,]
testing <- mydata[mydata$CALIBRAT==0,]

fit<-glm(CHURN~	REVENUE+	DIRECTAS+	ROAM+	CHANGEM+	UNANSVCE+	CUSTCARE+	THREEWAY+	INCALLS+	DROPBLK+	MONTHS+	ACTVSUBS+	PHONES+	EQPDAYS+	AGE1+	CHILDREN+	CREDITAA+	CREDITB+	
           CREDITC+	CREDITDE+	CREDITGY+	CREDITZ+	PRIZMRUR+	PRIZMUB+	REFURB+	WEBCAP+	MARRYUN+	MARRYYES+	
           MARRYNO+	NEWCELLY+	REVENUE_RECC_RATIO+	CHANGEM_IMPACT+	CHANGER_IMPACT+	UNIQ_ACTIV_RATIO,data = training,family = binomial(link="logit"))

summary(fit)

step(fit)


fit2 <- glm(CHURN ~ DIRECTAS + ROAM + CHANGEM + CUSTCARE + THREEWAY + INCALLS + 
              DROPBLK + MONTHS + PHONES + EQPDAYS + AGE1 + CHILDREN + CREDITAA + 
              CREDITB + CREDITDE + PRIZMUB + REFURB + WEBCAP + 
              MARRYUN + NEWCELLY + REVENUE_RECC_RATIO + CHANGEM_IMPACT + 
              CHANGER_IMPACT + UNIQ_ACTIV_RATIO, family = binomial(link = "logit"), data = training)

summary(fit2)

anova(fit2, test = 'Chisq')

library(QuantPsyc)
lm.beta(fit2)

################# Training ####################################

train1<- cbind(training, prob=predict(fit2, type="response"))
View(train1)
require(ROCR)
pred_train_fit2 <- prediction(train1$prob, train1$CHURN)
perf_fit2 <- performance(pred_train_fit2, "tpr", "fpr")
plot(perf_fit2)
abline(0, 1)
performance(pred_train_fit2, "auc")@y.values


fit2$coefficients
###### Logistic with tranformed variable, normal distributed variable #################

# hist(log(mydata$REVENUE)) ### Required transformation
# hist(mydata$CHANGEM)### No transformation required
# hist(sqrt(mydata$EQPDAYS)) ### Required transformation
# hist(log(mydata$ROAM)) ### Required transformation
# hist(log(mydata$MONTHS)) ### Required transformation
# hist(log(mydata$INCALLS)) ### Required transformation
# hist(log(mydata$AGE1)) ### Required transformation
# hist(log(mydata$UNANSVCE)) ### Required transformation
# hist(log(mydata$DROPBLK)) ### Required transformation
# hist(mydata$REVENUE_RECC_RATIO) ### No transformation required
# 
# mydata$ln_REVENUE <- log(mydata$REVENUE+1)
# mydata$ln_EQPDAYS <- sqrt(mydata$EQPDAYS+1)
# mydata$ln_ROAM <- log(mydata$ROAM+1)
# mydata$ln_MONTHS <- log(mydata$MONTHS+1)
# mydata$ln_INCALLS <- log(mydata$INCALLS+1)
# mydata$ln_AGE1 <- log(mydata$AGE1+1)
# mydata$ln_UNANSVCE <- log(mydata$UNANSVCE+1)
# mydata$ln_DROPBLK <- log(mydata$DROPBLK+1)
# 
# 
# training_lnvariables <- mydata[mydata$CALIBRAT==1,]
# testing_lnvariables <- mydata[mydata$CALIBRAT==0,]
# 
# fit3<-glm(CHURN~	ln_REVENUE+	DIRECTAS+	ln_ROAM+	CHANGEM+	ln_UNANSVCE+	CUSTCARE+	THREEWAY+	ln_INCALLS+	ln_DROPBLK+	ln_MONTHS+	ACTVSUBS+	PHONES+	ln_EQPDAYS+	ln_AGE1+	CHILDREN+	CREDITAA+	CREDITB+	
#            CREDITC+	CREDITDE+	CREDITGY+	CREDITZ+	PRIZMRUR+	PRIZMUB+	REFURB+	WEBCAP+	MARRYUN+	MARRYYES+	
#            MARRYNO+	NEWCELLY+	REVENUE_RECC_RATIO+	CHANGEM_IMPACT+	CHANGER_IMPACT+	UNIQ_ACTIV_RATIO,data = training_lnvariables,family = binomial(link="logit"))
# 
# 
# summary(fit3)
# 
# step(fit3)
# 
# fit4<-glm(CHURN ~ DIRECTAS + ln_ROAM + CHANGEM + ln_UNANSVCE + CUSTCARE + 
#             THREEWAY + ln_INCALLS + ln_DROPBLK + ln_MONTHS + PHONES + 
#             ln_EQPDAYS + ln_AGE1 + CHILDREN + CREDITAA + CREDITB + CREDITDE + 
#             CREDITZ + PRIZMUB + REFURB + WEBCAP + MARRYUN + NEWCELLY + 
#             REVENUE_RECC_RATIO + CHANGEM_IMPACT + CHANGER_IMPACT + UNIQ_ACTIV_RATIO,data = training_lnvariables,family = binomial(link="logit"))
# 
# train2<- cbind(training, prob=predict(fit4, type="response"))
# View(train2)
# require(ROCR)
# pred_train_fit2 <- prediction(train2$prob, train1$CHURN)
# perf_fit2 <- performance(pred_train_fit2, "tpr", "fpr")
# plot(perf_fit2)
# abline(0, 1)
# performance(pred_train_fit2, "auc")@y.values

#### AUC is poor even if we transform the variable to normally distribute, So will use fit2 only with existing varibales #####

###### Deciling ######################################


decLocations <- quantile(train1$prob, probs = seq(0.1,0.9,by=0.1))
train1$decile <- findInterval(train1$prob,c(-Inf,decLocations, Inf))
View(train1)

#Decile Analysis Reports
require(sqldf)
fit_train_DA <- sqldf("select decile, min(prob) as Min_prob
                       , max(prob) as max_prob
                       , sum(CHURN) as churn_Count
                       , (count(decile)-sum(CHURN)) as Non_churn_Count 
                      from train1
                      group by decile
                      order by decile desc")
View(fit_train_DA)

write.csv(fit_train_DA,"D:/R Analytics/Analytixlabs/Logistic/fit_train_DA.csv",row.names = F)


#################### Validation/Testing ###########################################

test1 <- cbind(testing, prob=predict(fit2,newdata = testing,type = "response"))

decLocations_test <- quantile(test1$prob,probs = seq(0.1,0.9,by=0.1))

test1$decile <- findInterval(test1$prob,c(-Inf,decLocations_test,Inf))

fit_test1_DA <- sqldf("select decile, min(prob) as Min_prob,
                      max(prob) as Max_prob,
                      sum(CHURN) as churn_count,
                      count(decile)-sum(CHURN) as Non_Churn_Count 
                      from test1 group by decile
                      order by decile desc")
View(fit_test1_DA)


write.csv(fit_test1_DA,"D:/R Analytics/Analytixlabs/Logistic/fit_test1_DA.csv",row.names = F)

### Based on the decile report, this is the best cut-off ######################

table(train1$prob>0.50, train1$CHURN)

table(test1$prob>0.50,test1$CHURN)

log_predict <- ifelse(test1$prob> 0.5,1,0)
pr <- prediction(log_predict,test1$CHURN)

library(Metrics)
perf <- performance(pr,measure = "tpr",x.measure = "fpr")
plot(perf) 
auc(test1$CHURN,log_predict)

## Model Performance is really bad using logistic regression, Boosting and RF will work  better in this case #####



